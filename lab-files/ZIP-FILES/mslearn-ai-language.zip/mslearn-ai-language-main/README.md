# Microsoft Learning Azure AI Language
Lab files for Azure AI Language modules
