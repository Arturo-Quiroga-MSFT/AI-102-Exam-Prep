# Develop AI solutions with Azure OpenAI

> **NOTE**: This repo is being archived, and is no longer maintained. Please visit the [generative AI apps](https://learn.microsoft.com/en-us/training/paths/create-custom-copilots-ai-studio/) learning path and [associated lab repo](https://github.com/MicrosoftLearning/mslearn-ai-studio), or [Azure AI Foundry documentation](https://learn.microsoft.com/en-us/azure/ai-foundry/)

This repo contains the instructions and assets required to complete the exercises in the [Develop AI solutions with Azure OpenAI](https://learn.microsoft.com/training/paths/develop-ai-solutions-azure-openai/) learning path on Microsoft Learn.
